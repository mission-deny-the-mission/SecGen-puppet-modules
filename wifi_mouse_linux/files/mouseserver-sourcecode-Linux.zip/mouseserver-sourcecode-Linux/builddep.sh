#!/bin/sh

# the following packages are requires to build on ubuntu

sudo apt-get install\
	     cmake\
	     g++\
	     libx11-dev libxtst-dev\
	     libgtk2.0-dev
